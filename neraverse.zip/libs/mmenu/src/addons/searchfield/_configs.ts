const configs : mmConfigsSearchfield = {
	clear: false,
	form: false,
	input: false,
	submit: false
};
export default configs;