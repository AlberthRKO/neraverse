const configs : mmConfigsDropdown = {
	offset: {
		button: {
			x: -5,
			y: 5
		},
		viewport: {
			x: 20,
			y: 20
		}
	},
	height: {
		max: 880
	},
	width: {
		max: 440
	}
};
export default configs;