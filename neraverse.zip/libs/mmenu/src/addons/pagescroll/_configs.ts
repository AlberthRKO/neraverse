const configs: mmConfigsPagescroll = {
    scrollOffset: 0,
    updateOffset: 50
};
export default configs;
