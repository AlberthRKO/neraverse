const configs : mmConfigsScreenreader = {
	text: {
		closeMenu: 'Close menu',
		closeSubmenu: 'Close submenu',
		openSubmenu: 'Open submenu',
		toggleSubmenu: 'Toggle submenu'
	}
};
export default configs;