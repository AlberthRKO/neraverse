export default {
    'Close menu': 'Закрыть меню',
    'Close submenu': 'Закрыть подменю',
    'Open submenu': 'Открыть подменю',
    'Toggle submenu': 'Переключить подменю'
};
