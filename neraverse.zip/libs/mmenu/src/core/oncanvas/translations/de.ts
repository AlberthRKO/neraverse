export default {
	'Menu': 'Menü'
};